//
//  get_mem_stats.c
//  Memory Management
//
//  Created by Tianshu Bao and Shawn Stern on 2/17/13.
//  Copyright (c) 2013 Tianshu Bao and Shawn Stern. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include "mem_impl.h"
#include "mem.h"

extern uintptr_t totalsize;

// Store statistics about the current state of the memory manager to the three given integers
void get_mem_stats(uintptr_t* total_size, uintptr_t* total_free, uintptr_t* n_free_blocks)
{
    free_list *current = list;
    
    while (current != NULL) {
        *total_free += current -> size;
        *n_free_blocks += 1;
        current = current -> next;
    }
    *total_size = totalsize;
}
