//
//  freemem.c
//  Memory Management
//
//  Created by Tianshu Bao and Shawn Stern on 2/17/13.
//  Copyright (c) 2013 Tianshu Bao and Shawn Stern. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include "mem_impl.h"
#include "mem.h"

// Return a block of storage to the free list at location p
void freemem(void *p)
{
    
}
