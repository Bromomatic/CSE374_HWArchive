//
//  print_heap.c
//  Memory Management
//
//  Created by Tianshu Bao and Shawn Stern on 2/17/13.
//  Copyright (c) 2013 Tianshu Bao and Shawn Stern. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include "mem_impl.h"
#include "mem.h"

// Prints a formatted list to file f which shows the blocks on the free list.
void print_heap(FILE *f)
{
    free_list *current = list;
	while (current!=NULL) {
		fprintf(f, "0x%p, 0x%x\n", current, (int)current -> size);
		current = current -> next;
	}
}