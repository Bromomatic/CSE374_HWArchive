//
//  mem.h
//  Memory Management
//
//  Created by Tianshu Bao and Shawn Stern on 2/17/13.
//  Copyright (c) 2013 Tianshu Bao and Shawn Stern. All rights reserved.
//  Contains public declarations of the functions used by clients.
#include "mem_impl.h"

#ifndef Memory_Management_mem_h
#define Memory_Management_mem_h

void* getmem(size_t size);
free_list* acquireBlock(int size);
boolean checkDivide(int size1, int size2);

void freemem(void *p);

void get_mem_stats(uintptr_t* total_size, uintptr_t* total_free, uintptr_t* n_free_blocks);

void print_heap(FILE *f);

#endif
