//
//  main.c
//  Memory Management
//
//  Created by Tianshu Bao and Shawn Stern on 2/17/13.
//  Copyright (c) 2013 Tianshu Bao and Shawn Stern. All rights reserved.
//

#include <stdio.h>
#include "mem.h"
#include "mem_impl.h"

// Tests getmem and freemem functionality
int main(int argc, const char * argv[])
{
    getmem(7000);
    getmem(5000);
    getmem(7000);
    getmem(4000);
	
	/*
    uintptr_t total_size = 0;
    uintptr_t total_free = 0;
    uintptr_t n_free_block = 0;
    
    FILE *f = fopen("/Users/Tianshu/Desktop/test.txt", "w");
    
    get_mem_stats(&total_size, &total_free, &n_free_block);
    print_heap(f);
	*/
    
    return 0;
}

