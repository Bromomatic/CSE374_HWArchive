//
//  getmem.c
//  Memory Management
//
//  Created by Tianshu Bao and Shawn Stern on 2/17/13.
//  Copyright (c) 2013 Tianshu Bao and Shawn Stern. All rights reserved.
//

#include <stdio.h>
#include <stdlib.h>
#include "mem_impl.h"
#include "mem.h"

#define new_block_size 10000
#define threshold 32

free_list *list;
uintptr_t totalsize = 0;

//Return a pointer to a new block of storage
//with at least specified size
void* getmem(uintptr_t size)
{
    if (size <= 0) {
        return NULL;
    }
    
    //Create new size slightly larger then specified size
    int new_size = (size/16.0 + 1)*16;
    
    //If the list is empty, acquire new memory block
    if (list == NULL && new_size < new_block_size) {
        list = acquireBlock(new_block_size);
    } else if (list == NULL && new_size >= new_block_size) {
        list = acquireBlock(new_size);
    }
    
    free_list *current = list;
    
    //Check if the first free_list block is large enough
    if ((current -> size) >= new_size) {
        if (checkDivide((int)(current -> size), new_size)) {
            free_list *newlist = (free_list*)((uintptr_t)current + (current->size) - new_size);
            newlist -> size = new_size;
            newlist -> next = NULL;
            current -> size = (current -> size) - new_size;
            return newlist;
        } else {
            list = NULL;
            current -> next = NULL;
            return  current;
        }
    }
    
    free_list *previous = current;
    
    //find the free_list block that is large enough
    while (((current -> next) != NULL) && ((current -> size) < new_size)) {
        previous = current;
        current = current -> next;
    }
    
    if ((current -> size) < new_size) {
        if (new_size < new_block_size) {
            current -> next = acquireBlock(new_block_size);
        } else if (new_size >= new_block_size) {
            current -> next = acquireBlock(new_size);
        }
        current = current -> next;
    }
    
    if (checkDivide((int)(current -> size), new_size)) {
        free_list *newlist = (free_list*)((uintptr_t)current + (current->size) - new_size);
        newlist -> size = new_size;
        newlist -> next = NULL;
        current -> size = (current -> size) - new_size;
        return newlist;
    } else {
        previous -> next = current -> next;
        current -> next = NULL;
        return  current;
    }
}


//Return a new block of memory based as specified size
free_list* acquireBlock(int size)
{
    free_list *new = (free_list*)malloc(size);
    new -> size = size;
    new -> next = NULL;
    totalsize += size;
    return new;
}

//Check if it's nesessary to divide a block
boolean checkDivide(int size1, int size2)
{
    return (size1-size2)>threshold;
}
